import numpy as np
import copy
import math
np.set_printoptions(threshold=np.inf)

point = np.loadtxt('exc.txt', delimiter=',', dtype=int)
print(point)
maplabel = np.loadtxt('maplabel.txt', delimiter=' ', dtype=int)
maplabel_privacy = copy.deepcopy(maplabel)

group_num = 36
for i in range(1,group_num+1):
    privacy_num = np.zeros([5,1], dtype=int)
    for j in range (len(point)):
        # print (point[j][3])
        privacy_num[point[j][3]] += 1
    # print(privacy_num)
    maxindex = np.argmax(privacy_num)
    for m in range(50):
        for n in range(50):
            if maplabel[m][n] == i:
                maplabel_privacy[m][n] = maxindex

for j in range (len(point)):
    m = point[j][1]
    n = point[j][0]
    maplabel_privacy[m][n] = point[j][3]

print(maplabel_privacy)
np.savetxt("maplabel_privacy.txt", maplabel_privacy, fmt='%d', delimiter=' ')
